'''import all'''
from .qq import qq
from .kuwo import kuwo
from .migu import migu
from .joox import joox
from .lizhi import lizhi
from .xiami import xiami
from .kugou import kugou
from .yiting import yiting
from .netease import netease
from .qianqian import qianqian
from .fivesing import fivesing
from .baiduFlac import baiduFlac