# 环境说明

## 测试环境
本人测试过的使用环境如下:
- 操作系统: Win10 / Mac OS
- Python版本: 3.6~3.8

## 依赖包 
musicdl相关依赖包需求如下:
```
click >= 7.0
requests >= 2.22.0
prettytable >= 0.7.2
pycryptodome >= 3.8.1
```