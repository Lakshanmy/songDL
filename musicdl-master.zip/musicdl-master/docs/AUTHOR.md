# 关于作者

```
学生党, 主要研究方向是计算机视觉, 顺便对信息安全感兴趣。

我的个人微信公众号是: Charles_pikachu (欢迎搜索关注)  

我的Github账号是: https://github.com/CharlesPikachu  

我的知乎账号是: https://www.zhihu.com/people/charles_pikachu

我的B站账号是: https://space.bilibili.com/406756145

个人邮箱: charlesblwx@gmail.com
```