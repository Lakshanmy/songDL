# 支持列表

|  平台                                     |   支持音乐搜索?    |  支持音乐下载?       |
|  :----:                                   |   :----:           |  :----:              |
|  [QQ音乐](https://y.qq.com/)              |   ✓                |  ✓                   |
|  [荔枝FM](http://m.lizhi.fm)              |   ✓                |  ✓                   |
|  [一听音乐](https://h5.1ting.com/)        |   ✓                |  ✓                   |
|  [酷我音乐](http://yinyue.kuwo.cn/)       |   ✓                |  ✓                   |
|  [酷狗音乐](http://www.kugou.com/)        |   ✓                |  ✓                   |
|  [虾米音乐](https://www.xiami.com/)       |   ✓                |  ✓                   |
|  [千千音乐](http://music.taihe.com/)      |   ✓                |  ✓                   |
|  [咪咕音乐](http://www.migu.cn/)          |   ✓                |  ✓                   |
|  [JOOX音乐](https://www.joox.com/limits)  |   ✓                |  ✓                   |
|  [5SING音乐](http://5sing.kugou.com/)     |   ✓                |  ✓                   |
|  [网易云音乐](https://music.163.com/)     |   ✓                |  ✓                   |
|  [百度无损音乐](http://music.baidu.com/)  |   ✓                |  ✓                   |