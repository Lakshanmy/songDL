.. musicdl documentation master file, created by
   sphinx-quickstart on Sat Feb 29 22:07:23 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

musicdl中文文档
========================================

.. toctree::
	:maxdepth: 2
	
	STATEMENTS.md
	SUPPORTLIST.md
	ENVIROMENT.md
	NONDEVELOPER.md
	DEVELOPER.md
	LOG.md
	AUTHOR.md